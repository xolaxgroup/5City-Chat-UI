config={}
Config.cenadw = 200 --Cena Deepwebu
Config.cenatwt = 25 --Cena Tweetera
Config.cenareklama = 400 --Cena Reklamy

